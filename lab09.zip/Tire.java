//Erin Owens Copyright 2024
/**
 * Class used to describe the tire type used by a street-legal consumer
 * or light-commerical vehicle.
 * 
 * IT MUST EXTEND PartGoup.
 */
public class Tire extends PartGroup{	

	/**
	 * Enumeration of common tire types.
	 */
	enum Type{
		P, 
		LT,
		ST;
	}

	/**
	 * Enumeration of common tire construction types.
	 */
	enum Construction{
		R,
		D;
	}

	/**
	 * Enumeration of common tire speed ratings.
	 */
	enum SpeedRating{
		M, N, P, Q, R, S, H;
	}

	/**
	 * 
	 * FULL constructor METHOD (no default required)
	 * 
	 * @param id
	 * @param partNo
	 * @param price
	 * @param count
	 * @param type : Tire.Type
	 * @param width : int
	 * @param aspectRatio : int
	 * @param construction : Tire.Construction
	 * @param diameter : int
	 * @param loadIndex : int
	 * @param speed : Tire.SpeedRating
	 */
	
	public Tire(int id, String partNo, double price, int count, Type type, int width, int aspectRatio, Construction construction, int diameter, int loadIndex, SpeedRating speed) {
		super(id, partNo, price, count);
		this.type = type;
		this.width = width;
		this.aspectRatio = aspectRatio;
		this.construction = construction;
		this.diameter = diameter;
		this.loadIndex = loadIndex;
		this.speed = speed;		
	}
	 
	/**
	 * toString METHOD
	 * 
	 * See tests for description of string built by this method.
	 */
	public String toString() {
		String aTire = (super.toString() + ", " + type + " " + width + "/" + aspectRatio + " " + construction + " " + diameter + " " + loadIndex + " " + speed);
		return aTire;
	}
	
	
private Type type;
private int width;
private int aspectRatio;
private Construction construction;
private int diameter;
private int loadIndex;
private SpeedRating speed;

}
