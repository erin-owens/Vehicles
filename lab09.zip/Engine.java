//Erin Owens copyright 2024
/**
 * Class used to describe a consumer or light-commerical grade engine.
 */
public class Engine extends UniquePart{

	/**
	 * Layout
	 * 
	 * + Public enum of common engine layouts.
	 */
	enum Layout{
		Inline,
		Flat,
		V;
	}

	/**
	 * Configuration
	 * 
	 * + Public enum of common engine cylinder configurations.
	 */
	enum Configuration{
		Twin,
		Four,
		Six,
		Eight;
	}

	/**
	 * Fuel
	 * 
	 * Public enum of common engine fuel types.
	 */
	enum Fuel{
		Petrol,
		Diesel,
		Alternative;
	}

	/**
	 * FULL constructor METHOD (no default required)
	 * 
	 * @param displacement : double 
	 * @param layout : Engine.Layout
	 * @param configuration : Engine.ConfigurationType
	 * @param fuel : Engine.Fuel
	 */
	public Engine(int id, String partNo, double price, String uuid, double displacement, Layout layout, Configuration configuration, Fuel fuel) {
		super(id, partNo, price, uuid);
		this.displacement = displacement;
		this.layout = layout;
		this.configuration = configuration;
		this.fuel = fuel;
	}	
	
	/**
	 * toString METHOD
	 * 
	 * Engines have colloquial descriptions that are used by mechanics and the like. Use
	 * their terminology to "name" your engine instances as follows.
	 * 
	 * Displacement is added as a floating point with one decimal place followed by
	 *   the letter "L" for liters.
	 * Layout and configuration are handled as follows:
	 *   - Inline and Flat configuations:
	 *       Inline Twin, Inline Four, Inline Six, Inline Eight
	 *       Flat Twin, Flat Four, Flat Six, Flat Eight
	 *   - V configurations:
	 *       V Twin, Four Cylinder, Six Cylinder, V8
	 * Only add fuel type if not petrol. Do so by adding fuel type in parenthesis at
	 *   the end, e.g. (diesel).
	 */
	public String toString() {
	//ensures the displacement value is a decimal rounded to the tenths place
		String anEngine = super.toString() + String.format(", %.1fL", displacement);
		//ensures the correct terminology is used based on the engine layout (ex. V8 vs Four Cylinder)
		if(this.layout.equals(Layout.V)) {
			if(this.configuration.equals(Configuration.Twin)){
				anEngine += " " + (this.layout + " " + this.configuration);
			}
			if(this.configuration.equals(Configuration.Eight)){
				anEngine += " " + (this.layout + "8");
			}
			if(this.configuration.equals(Configuration.Four) || this.configuration.equals(Configuration.Six)) {
				anEngine += " " + (this.configuration + " cylinder");
			}
		}
		else {
			anEngine += " "+ this.layout + " " + this.configuration;
		}
		if(!this.fuel.equals(Fuel.Petrol)) {
			anEngine += " " + ("(" + fuel.toString().toLowerCase() + ")");
		}
		return anEngine;
	}	
	
private double displacement;
private Layout layout;
private Configuration configuration;
private Fuel fuel;
}
