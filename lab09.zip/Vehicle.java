//Erin Owens copyright 2024
import java.util.ArrayList;
/**
 * Class representing a vehicle. It consists of vehicle-specific
 * attributes as well as a list of parts. You MUST store that data
 * as a Part instance - consider using an ArrayList.
 */
public class Vehicle{	

	/**
	 * FULL constructor METHOD (no defaults needed)
	 * 
	 * @param make : String
	 * @param model : String
	 * @param doors : int
	 */
	public Vehicle(String make, String model, int doors) {
		this.make = make;
		this.model = model;
		this.doors = doors;
		this.parts = new ArrayList<>();
	}
	
	/**
	 * Mutator method addPart
	 * 
	 * Adds a new part to the list of parts making up a vehicle.
	 * 
	 * @param addMe
	 */
	public void addPart(Part addMe) {
		parts.add(addMe);
	}
	
	/**
	 * toString METHOD
	 * 
	 * When doors > 0, begin string with #-door where # is the number of doors, follow
	 *   with the string "Part List:" and a list of each part of stored by the vehicle,
	 *   delimited by newline characters (\n).
	 *   
	 * See tests for more thorough description of return string.
	 */
	//print the engine string, then the tire string
	public String toString() {
		StringBuilder aVehicle = new StringBuilder();
		if(doors > 0) {
			aVehicle.append(doors + "-door ");
		}
		aVehicle.append(make + " " + model + "\n");
		aVehicle.append("Part List:\n");
		
		for(int i = 0; i < parts.size(); i++) {
			aVehicle.append(" ").append(parts.get(i).toString());
			if(i != parts.size()-1) {
				aVehicle.append("\n");
			}
			//it looks like there should be a space before the identifiers in the tests but the test is failing so I'm not sure what
			//the formatting issue is...
		}				
		return aVehicle.toString();
	}

private ArrayList<Part> parts;	
private String make;
private String model;
private int doors;
}
