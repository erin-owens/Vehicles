//Erin Owens copyright 2024
/**
 * The Part class is a parent class that will be extended by child classes to
 * represent common parts added to vehicles, e.g., tires and engines. There
 * will be two additional child classes between Tire and Engine, representing
 * a Part that is unique in the class and a part that is often added in groups.
 * See PartGroup and UniquePart for more.
 */
public class Part{

	/**
	 * Full constructor. Sets all private attributes.
	 * 
	 * @param id : int
	 * @param partNo : String
	 * @param price : double
	 */
	public Part(int id, String partNo, double price) {
		this.id = id;
		this.partNo = partNo;
		this.price = price;
		
	}
	
	/**
	 * Accessor id for part's identifier
	 * 
	 * @return Value of identifier
	 */
	public int id(){
		return id;
	}
	
	/**
	 * Accessor partNo for part's part number
	 * 
	 * @return Value of part number
	 */
	public String partNo() {
		return partNo;
	}
	
	/**
	 * Accessor price for part's price
	 * 
	 * @return Value of part price
	 */
	public double price() {
		return price;
	}
	
	/**
	 * The equals method compares two parts based on their part identifier
	 * attributes.
	 * 
	 * @param rhs : Part The right-hand-side of this == rhs
	 * 
	 * @return True if the two Parts' identifiers are the equal.
	 */
	public boolean Equals(Part rhs) {
		if(rhs.id == id) { //this.id or id? or does it not matter?
			return true;
		}
		return false;
	}
	
	/**
	 * The toString method builds a comma-delimited concatenation of the
	 * three attributes.
	 * 
	 * The identifier is displayed as a 10 digit integer, left-padded with zeros
	 * if it is less than 10 digits.
	 * ", "
	 * The part number is second.
	 * ","
	 * The price is given with a leading dollar sign and is rounded to two digits.
	 * 
	 * @return The string described above.
	 */
	public String toString() {
		//format the id and price		
		String formatID = Integer.toString(id);
		if(formatID.length() < 10) {
			formatID = String.format("%010d", id);
		}
		
		String formatPrice =  String.format("%.2f", price);
		
		String partInstance = (formatID + ", " + partNo + ", $" + formatPrice);
		
		return partInstance;
	}	
private int id;
private String partNo;
private double price;
}	
